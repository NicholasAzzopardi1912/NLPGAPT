from .SVM_NER_MAPA import create_svm_ner_mapa
